﻿namespace IDZ_szi
{
    partial class Operator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel17 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button18 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.label21 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.textBox2);
            this.panel17.Controls.Add(this.button20);
            this.panel17.Controls.Add(this.label50);
            this.panel17.Controls.Add(this.label45);
            this.panel17.Controls.Add(this.dateTimePicker3);
            this.panel17.Controls.Add(this.comboBox17);
            this.panel17.Controls.Add(this.label51);
            this.panel17.Controls.Add(this.comboBox3);
            this.panel17.Controls.Add(this.label52);
            this.panel17.Controls.Add(this.label53);
            this.panel17.Location = new System.Drawing.Point(554, 390);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(530, 224);
            this.panel17.TabIndex = 22;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(289, 127);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(229, 27);
            this.textBox2.TabIndex = 31;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button20.Location = new System.Drawing.Point(176, 173);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(161, 39);
            this.button20.TabIndex = 13;
            this.button20.Text = "одобрить!";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label50.Location = new System.Drawing.Point(285, 104);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(60, 20);
            this.label50.TabIndex = 30;
            this.label50.Text = "сумма";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label45.Location = new System.Drawing.Point(172, 12);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(165, 22);
            this.label45.TabIndex = 4;
            this.label45.Text = "одобрить заявку";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker3.Location = new System.Drawing.Point(14, 127);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(269, 27);
            this.dateTimePicker3.TabIndex = 29;
            // 
            // comboBox17
            // 
            this.comboBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(13, 69);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(270, 28);
            this.comboBox17.TabIndex = 24;
            this.comboBox17.SelectedValueChanged += new System.EventHandler(this.comboBox17_SelectedValueChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label51.Location = new System.Drawing.Point(11, 106);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(118, 20);
            this.label51.TabIndex = 28;
            this.label51.Text = "дата оплаты";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Безналичный расчет",
            "Наличный расчет"});
            this.comboBox3.Location = new System.Drawing.Point(289, 69);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(229, 28);
            this.comboBox3.TabIndex = 25;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label52.Location = new System.Drawing.Point(285, 46);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(134, 20);
            this.label52.TabIndex = 27;
            this.label52.Text = "способ оплаты";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label53.Location = new System.Drawing.Point(9, 46);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(67, 20);
            this.label53.TabIndex = 26;
            this.label53.Text = "заявка";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.textBox1);
            this.panel16.Controls.Add(this.label47);
            this.panel16.Controls.Add(this.dateTimePicker2);
            this.panel16.Controls.Add(this.label48);
            this.panel16.Controls.Add(this.label49);
            this.panel16.Controls.Add(this.label46);
            this.panel16.Controls.Add(this.comboBox9);
            this.panel16.Controls.Add(this.comboBox2);
            this.panel16.Controls.Add(this.button18);
            this.panel16.Controls.Add(this.label43);
            this.panel16.Location = new System.Drawing.Point(12, 390);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(535, 224);
            this.panel16.TabIndex = 21;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(291, 127);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(229, 27);
            this.textBox1.TabIndex = 23;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label47.Location = new System.Drawing.Point(287, 104);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(60, 20);
            this.label47.TabIndex = 22;
            this.label47.Text = "сумма";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker2.Location = new System.Drawing.Point(16, 127);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(269, 27);
            this.dateTimePicker2.TabIndex = 21;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label48.Location = new System.Drawing.Point(13, 106);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(118, 20);
            this.label48.TabIndex = 20;
            this.label48.Text = "дата оплаты";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label49.Location = new System.Drawing.Point(287, 46);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(134, 20);
            this.label49.TabIndex = 19;
            this.label49.Text = "способ оплаты";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label46.Location = new System.Drawing.Point(11, 46);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(67, 20);
            this.label46.TabIndex = 16;
            this.label46.Text = "заявка";
            // 
            // comboBox9
            // 
            this.comboBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "Безналичный расчет",
            "Наличный расчет"});
            this.comboBox9.Location = new System.Drawing.Point(291, 69);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(229, 28);
            this.comboBox9.TabIndex = 15;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(15, 69);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(270, 28);
            this.comboBox2.TabIndex = 14;
            this.comboBox2.SelectedValueChanged += new System.EventHandler(this.comboBox2_SelectedValueChanged);
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button18.Location = new System.Drawing.Point(179, 173);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(161, 39);
            this.button18.TabIndex = 13;
            this.button18.Text = "одобрить!";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label43.Location = new System.Drawing.Point(175, 12);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(165, 22);
            this.label43.TabIndex = 4;
            this.label43.Text = "одобрить заявку";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.button16);
            this.panel15.Location = new System.Drawing.Point(553, 320);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(531, 64);
            this.panel15.TabIndex = 20;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button16.Location = new System.Drawing.Point(19, 11);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(499, 38);
            this.button16.TabIndex = 7;
            this.button16.Text = "добавить заявку на комплексное решение";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.button15);
            this.panel14.Location = new System.Drawing.Point(12, 320);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(535, 64);
            this.panel14.TabIndex = 19;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button15.Location = new System.Drawing.Point(12, 9);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(508, 42);
            this.button15.TabIndex = 6;
            this.button15.Text = "добавить заявку на сзи";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.button19);
            this.panel13.Controls.Add(this.dataGridView8);
            this.panel13.Controls.Add(this.label21);
            this.panel13.Location = new System.Drawing.Point(554, 13);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(531, 300);
            this.panel13.TabIndex = 18;
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button19.Location = new System.Drawing.Point(176, 255);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(161, 34);
            this.button19.TabIndex = 14;
            this.button19.Text = "посмотреть!";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // dataGridView8
            // 
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(18, 48);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.RowHeadersWidth = 51;
            this.dataGridView8.RowTemplate.Height = 24;
            this.dataGridView8.Size = new System.Drawing.Size(499, 194);
            this.dataGridView8.TabIndex = 8;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(122, 16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(316, 22);
            this.label21.TabIndex = 5;
            this.label21.Text = "заявки на комплексное решение";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.button17);
            this.panel12.Controls.Add(this.dataGridView3);
            this.panel12.Controls.Add(this.label6);
            this.panel12.Location = new System.Drawing.Point(12, 12);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(536, 301);
            this.panel12.TabIndex = 17;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button17.Location = new System.Drawing.Point(179, 256);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(161, 34);
            this.button17.TabIndex = 3;
            this.button17.Text = "посмотреть!";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(15, 49);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(505, 194);
            this.dataGridView3.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(185, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "заявки на сзи";
            // 
            // Operator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 629);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Name = "Operator";
            this.Text = "Operator";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Operator_FormClosed);
            this.Load += new System.EventHandler(this.Operator_Load);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label6;
    }
}